package edbc;
import java.sql.SQLException;
import java.util.Scanner;

public class AllFunction {

	private static Scanner sc;

	public static void main(String[] args) throws SQLException {
		
		sc = new Scanner(System.in);
		
		while(true) {
		System.out.println("Enter your choice");
		System.out.println("1. Display Record");
		System.out.println("2. Add new Record");
		System.out.println("3. Update record(name)");
		System.out.println("4. Delete record based on id");
		int ch=sc.nextInt();
		
		switch(ch) {
		case 1: Operations.displayRecord();
		         break;
		case 2: Operations.addRecord();
		          break;
		case 3:Operations.updateRecord();
		         break;
		case 4: Operations.deleteRecord();
		         break;
		default : System.out.println("Invalid input");
		            
		}
		System.out.println("Do you want to contine y/n");
		char choice=sc.next().toLowerCase().charAt(0);
		if(choice!='y') {
			break;
		}
		}
     }
}



