package edbc;
import java.sql.Connection;
import java.sql.DriverManager;

public class Employee {
	static Connection con= null;
	public static Connection getConnection()
		{
			String driver="com.mysql.cj.jdbc.Driver";
			String url="jdbc:mysql://localhost:3306/vickydatabase";
			String un="root";
			String pass="root";
			try {
				Class.forName(driver);
				con = DriverManager.getConnection(url, un, pass);
				if(con==null)
				{
					System.out.println("Connection error");
				}
				}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return con;
  }
}

