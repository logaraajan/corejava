package edbc;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Operations {
	private static Connection connect;
	private static Statement st;
	private static ResultSet rs;
	private static String empname;
	private static int empid;
	private static float empsalary;
	private static String empdept;
	private static Scanner sc;
	
	public static void displayRecord() throws SQLException{
		connect = Employee.getConnection();
		st=connect.createStatement();
		String select="select * from Employee";
		rs=st.executeQuery(select);
		System.out.println("EmpID \t\t EmpName \t EmpSalary \t EmpDept");
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t"+rs.getFloat(3)+"\t\t"+rs.getString(4));
		}
		}
	public static void addRecord() throws SQLException {
		connect=Employee.getConnection();
		st=connect.createStatement();
		sc=new Scanner(System.in);
		System.out.println("Enter Employee name");
		empname=sc.nextLine();
		System.out.println("Enter employee id");
		empid=sc.nextInt();
		System.out.println("Enter Employee salary");
		empsalary=sc.nextFloat();
		System.out.println("Enter employee Dept");
		empdept=sc.next();
		String select = "select * from employee where eid = "+ empid;
		rs=st.executeQuery(select);
		if(!rs.next())
		{
			String insert="insert into employee values("+empid+" ,' "+empname+"',"+empsalary+",'"+empdept+"')";
		    int i=st.executeUpdate(insert);
		    if(i>0)
		    {
		    	System.out.println("Record inserted successfully");
		    	}
		    else
		    {
		    	System.out.println("Record is not inserted successfully");
			}
		}
		else {
			System.out.println(empid+" Already exists");
		}
		}
	public static void updateRecord() throws SQLException {
		
		String select;
		connect=Employee.getConnection();
		st=connect.createStatement();
		while(true)
		{
		sc=new Scanner(System.in);
		System.out.println("Menu for update record");
		System.out.println("-----------------------");
		System.out.println("Enter your choice");
		System.out.println("1. To change name");
		System.out.println("2. To change Salary");
		System.out.println("3. To change Department");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			System.out.println("Enter Employee Id");
			empid=sc.nextInt();
			System.out.println("Enter Employee name to update");
			empname=sc.next();
			
			System.out.println(" ");
			select = "select * from employee where eid = "+ empid;
			
			rs=st.executeQuery(select);
			if(rs.next())
			{
				String update="update Employee set ename='"+empname+"' where eid="+empid;
			    int retval=st.executeUpdate(update);
			    if(retval>0) {
			     System.out.println("Record is updated");
			    }
			    else {
			     System.out.println("Some error occured not updated record");
			    }
			 }
			else 
			   {
			    System.out.println(empid+" not exists in database updation not possible");
			   }
			break;
		case 2:
			System.out.println("Enter Employee salary");
			empsalary=sc.nextFloat();
			
			System.out.println("Enter Employee Id");
			empid=sc.nextInt();
			
			select = "select * from employee where eid = "+ empid;
			rs=st.executeQuery(select);
			if(rs.next())
			{
				String update="update Employee set esalary="+empsalary+" where eid="+empid;
			    int retval=st.executeUpdate(update);
			    if(retval>0) {
			     System.out.println("Record is updated");
			    }
			    else {
			     System.out.println("Some error occured not updated record");
			    }
			 }
			else 
			   {
			    System.out.println(empid+" not exists in database updation not possible");
			   }
			break;
		case 3:
			System.out.println("Enter Employee Id");
			empid=sc.nextInt();
			System.out.println("Enter employee Dept");
			empdept=sc.next();
			
			
			select = "select * from employee where eid = "+ empid;
			rs=st.executeQuery(select);
			if(rs.next())
			{
				String update="update Employee set edept='"+empdept+"' where eid="+empid;
			    int retval=st.executeUpdate(update);
			    if(retval>0) {
			     System.out.println("Record is updated");
			    }
			    else {
			     System.out.println("Some error occured not updated record");
			    }
			 }
			else 
			   {
			    System.out.println(empid+" not exists in database updation not possible");
			   }
			break;
		default:
			System.out.println("Invalid option");
		}
		System.out.println("Do you want to continue Y/N");
		char ch1=sc.next().toLowerCase().charAt(0);
		if(ch1!='y')
		{
			break;
		}
	}
}
	
	public static void deleteRecord() throws SQLException {
		connect=Employee.getConnection();
		st=connect.createStatement();
		sc=new Scanner(System.in);
		System.out.println("Enter employee id");
		empid=sc.nextInt();
		String select = "select * from employee where eid = "+ empid;
		rs=st.executeQuery(select);
		if(rs.next())
		{
			String delete="delete from employee where eid="+empid;
			int delval = st.executeUpdate(delete);
			if(delval>0)
			{
				System.out.println("Record is Deleted successfully");
				}
			else
			{
				System.out.println("Record is not Deleted");
				}
			}
		else {
			System.out.println(empid+" not exists in database deletion not possible");
			}
		}
	}
