package project5;

public class EvenNatural {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,sum;
		sum=0;
		i=2;
		while(i<=100) {
			sum=sum+i; 
			i=i+2;
		}
	    System.out.println("sum=" +sum );
	    
	    
	}
        
	
}
