//looping //

package project5;

public class Integer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++) {
			if(i==5) {
				//break;
				continue;
			}else {
			System.out.println(i);
			}
		}
		
		System.out.println("out side for loop");



	}

}
