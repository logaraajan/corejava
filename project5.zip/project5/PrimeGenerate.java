package project5;
import java.util.Scanner;
public class PrimeGenerate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a number range to generate prime numbers in between");
        Scanner scanner = new Scanner(System.in);
        int number1 = scanner.nextInt();
        int number2 = scanner.nextInt();

        if (number1 >= number2) {
            System.out.println("Number2 must be greater then number1");
            System.exit(0);
        }
        while (number1 <= number2) {
            int i = 2, count = 0;
            while (i <= number1 / 2) {
                if (number1 % i == 0) {
                    count++;
                    break;
                }
                i++;

            }
            if (count == 0) {
                System.out.println(number1 + " is prime number");
            }
            number1++;
           

	}

}
}
