package project5;

public class OddNatural {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,sum;
		sum=0;
		i=1;
		while(i<=99) {
			sum=sum+i; 
			i=i+2;
		}
	    System.out.println("sum=" +sum );

	}

}
