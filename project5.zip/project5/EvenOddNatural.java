package project5;

public class EvenOddNatural {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 1,2,3,.....100
		int i,sum,sum1,sum2;
		sum=0;
		sum1=0;
		sum2=0;
		
		i=1;
		while(i<=100) {
			sum=sum+i;  
			if(i%2==0) {
				sum1=sum1+i;
			}
	        if(i%2!=0) {
	        	sum2=sum2+i;
			}
	        i=i+1;
				
		}
		System.out.println("the sum of natural numbers=" +sum);
	    System.out.println("The sum of odd natural numbers="  +sum2 );
	    System.out.println("The sum of even natural numbers="  +sum1 );


	}

}
